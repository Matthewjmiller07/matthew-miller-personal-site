# Mega Bible API — Claude Code Setup Instructions

Hand this file (and the zip) to Claude Code and say:
**"Please set up the Mega Bible API for my site using these instructions."**

---

## What this is

A Cloudflare Worker that serves as a unified Tanakh annotation API at:
`theothermatthewmiller.com/api/bible/*`

It pulls from two Supabase tables (Tanakh Annotations + Literary Bible)
and enriches results with live Sefaria text and Open Bible cross-references.

---

## Step 1 — Unzip and open the folder

```bash
unzip mega-bible-api.zip
cd mega-bible-api
```

---

## Step 2 — Install Wrangler (Cloudflare's CLI)

```bash
npm install -g wrangler
```

---

## Step 3 — Log in to Cloudflare

```bash
wrangler login
```

This opens a browser window. Log in with the Cloudflare account that manages
**theothermatthewmiller.com**. Once authenticated, return to the terminal.

---

## Step 4 — Confirm your zone name

The `wrangler.toml` routes traffic from `theothermatthewmiller.com/api/bible/*`
to this Worker. Verify the domain in Cloudflare matches exactly:

Open `wrangler.toml` and confirm this line matches your Cloudflare zone:
```toml
routes = [
  { pattern = "theothermatthewmiller.com/api/bible/*", zone_name = "theothermatthewmiller.com" }
]
```

If your zone is registered differently (e.g. with www), update both values.

---

## Step 5 — Deploy

```bash
wrangler deploy
```

You should see output like:
```
Total Upload: ~8 KB
Uploaded mega-bible-api (X.XXs)
Published mega-bible-api (X.XXs)
  https://mega-bible-api.<your-subdomain>.workers.dev
  theothermatthewmiller.com/api/bible/*
```

Both URLs now work. The `.workers.dev` one is a free backup URL.

---

## Step 6 — Test it

```bash
curl https://theothermatthewmiller.com/api/bible/
curl https://theothermatthewmiller.com/api/bible/verse/Genesis/1/1
curl https://theothermatthewmiller.com/api/bible/devices
curl https://theothermatthewmiller.com/api/bible/search?q=chiasmus
```

All should return JSON. The verse endpoint includes Hebrew text, English text,
your personal annotations, literary devices, and cross-references.

---

## Step 7 (Optional) — Switch to private mode

If you want to lock the API to yourself only:

**Set your secret key (one time):**
```bash
wrangler secret put API_SECRET_KEY
```
Enter any strong passphrase when prompted. This is stored securely in Cloudflare
and never in any file.

**Update wrangler.toml:**
```toml
[vars]
API_MODE = "private"
```

**Redeploy:**
```bash
wrangler deploy
```

Now all requests require the header `X-API-Key: your-passphrase`.

To switch back to public at any time, set `API_MODE = "public"` and redeploy.

---

## All endpoints

| URL | What it returns |
|-----|----------------|
| `GET /api/bible/` | API docs + endpoint list |
| `GET /api/bible/verse/:book/:chapter/:verse` | Hebrew + English text, your annotations, literary devices, cross-refs |
| `GET /api/bible/book/:book` | All annotations for a book |
| `GET /api/bible/device/:device` | All verses tagged with a literary device |
| `GET /api/bible/search?q=` | Full-text search across comments, words, notes |
| `GET /api/bible/devices` | List of all literary devices in your database |
| `GET /api/bible/books` | List of all annotated books |

**Example verse references:**
```
/api/bible/verse/Genesis/22/14
/api/bible/verse/Psalms/23/1
/api/bible/verse/Isaiah/6/3
/api/bible/verse/Song of Songs/2/1
```

---

## Using it in Claude.ai

Once deployed, in any Claude.ai conversation:

> "Fetch https://theothermatthewmiller.com/api/bible/verse/Genesis/22/14
>  and explain the literary devices and annotations"

> "Search https://theothermatthewmiller.com/api/bible/search?q=binding
>  and summarize what you find"

Claude fetches your data and synthesizes it — no extra API cost.

---

## Files in this zip

| File | Purpose |
|------|---------|
| `index.js` | The Worker — all routing, auth, Supabase queries, external API calls |
| `wrangler.toml` | Cloudflare config — Worker name, domain routing, auth mode |
| `README.md` | Reference docs |

---

## Troubleshooting

**"No route matched" error** — Your domain's DNS must be proxied through Cloudflare
(orange cloud in DNS settings). Check that `theothermatthewmiller.com` is active
in your Cloudflare dashboard.

**Supabase returns empty arrays** — The RLS (Row Level Security) policies on your
Supabase tables must allow anon reads. Check in Supabase → Authentication → Policies
that your `Tanakh Annotations` and `literary_bible` tables have a public SELECT policy.

**"Authentication error" from Cloudflare** — Run `wrangler login` again and retry.

**Worker deploys but domain route doesn't work** — Make sure the zone name in
`wrangler.toml` exactly matches the zone shown in your Cloudflare dashboard
(Websites → your domain → Overview → Zone Name).
