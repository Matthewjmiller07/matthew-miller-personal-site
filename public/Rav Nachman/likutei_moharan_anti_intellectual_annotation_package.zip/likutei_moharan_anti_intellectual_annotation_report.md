# Likutei Moharan — Anti-Intellectual / Anti-Philosophy Annotation Report

## Bottom line

Rebbe Nachman can be read as sharply anti-philosophical and anti-rationalist in the sense that he warns against external wisdom, speculative inquiry, and intellect detached from faith or deeds. He is not anti-intellectual in a blanket sense: he valorizes Torah wisdom, daat, depth, and holy sechel, but insists that intellect must be governed by faith, temimut, mitzvot, prayer, and practice.

## Scan summary

- Hebrew segments scanned: **7182**
- English segments scanned: **7107**
- Aligned Hebrew/English segments: **7107**
- Total annotations: **256**
- High-relevance annotations: **43**

## Label counts

- **HERESY_APICORUS**: 86 — Associates certain intellectual paths/questions with apikorsut/heresy.
- **CRITIQUE_SPECULATIVE_INQUIRY**: 45 — Warns against speculative inquiry/investigation, especially where it exceeds faith or leads into confusion.
- **COUNTER_TORAH_STUDY**: 37 — Praises Torah study / beit midrash as the remedy, not anti-learning.
- **SIMPLICITY_PSHITUT**: 34 — Values simplicity/temimut/pshittut over sophistication.
- **CRITIQUE_PHILOSOPHY**: 26 — Names philosophy/philosophers as harmful, misleading, or insufficient.
- **COUNTER_POSITIVE_INTELLECT**: 24 — Positive valuation of holy intellect, wisdom, understanding, or daat.
- **LIMITS_OF_HUMAN_INTELLECT**: 12 — Marks a boundary where human intellect cannot grasp/resolve divine matters.
- **FALSE_WISDOM_CRITIQUE**: 11 — Critiques wisdom that is self-generated, egoic, evil, or detached from Torah.
- **CRITIQUE_EXTERNAL_WISDOM**: 11 — Critiques חכמות חיצוניות / external or alien wisdom as spiritually dangerous.
- **PRACTICE_OVER_STUDY**: 10 — Subordinates study/intellect to practice and concrete religious action.
- **COUNTER_DEEP_STUDY**: 9 — Praises depth, reasoning, proofs, logic, or close study of Torah.
- **FAITH_OVER_INQUIRY**: 9 — Explicitly elevates faith over investigation/wisdom.
- **ANTI_NATURALISM**: 3 — Opposes naturalistic explanation when it displaces prayer, miracles, or providence.
- **WISDOM_WITHOUT_DEEDS_DANGER**: 1 — Warns that intellect/wisdom exceeding deeds becomes spiritually dangerous.

## Strongest supporting passages

### ann_0011 — A Pleasant Song, segment 5
**Labels:** FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 3

> **Hebrew:** [[חַכְמֵיהֶם בָּדוּ מִלִּבָּם]] נִימוּסִים [[בְּשִׂכְלָם הָאֱנוֹשִׁי]]

**Note:** Critiques false or evil wisdom, not wisdom as such.

### ann_0087 — Likutei Moharan I, Lesson 52, segment 1.2
**Labels:** HERESY_APICORUS, FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 4

> **Hebrew:** כִּי יֵשׁ [[אֶפִּיקוֹרְס]]ִים שֶׁאוֹמְרִים, שֶׁהָעוֹלָם הוּא מְחֻיַּב הַמְּצִיאוּת, וּלְפִי [[דַּעְתָּם הָרָעָה]] הַמְשֻׁבֶּשֶׁת, נִדְמֶה לָהֶם, שֶׁיֵּשׁ עַל־זֶה רְאָיוֹת וּמוֹפְתִים, חַס וְשָׁלוֹם, מִמִּנְהַג הָעוֹלָם. אֲבָל בֶּאֱמֶת הֶבֶל יִפְצֶה פִּיהֶם, כִּי בֶּאֱמֶת הָעוֹלָם וּמְלוֹאוֹ הוּא אֶפְשָׁרִי הַמְּצִיאוּת,
> **English:** There are [[heretic]]s who say that the world is a necessary reality. Based on [[their evil and erroneous opinion]] it seems to them that they have proofs and examples of this, God forbid, from the way the world functions. But in fact their mouths spew foolishness. For the truth is that the world and all it contains are a contingent reality.

**Note:** Connects the issue to apikorsut/heresy rather than neutral intellectual life. Critiques false or evil wisdom, not wisdom as such.

### ann_0098 — Likutei Moharan I, Lesson 55, segment 6.3
**Labels:** CRITIQUE_PHILOSOPHY, WISDOM_WITHOUT_DEEDS_DANGER
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וּקְטַנֵּי קוֹמָה, שֶׁהָעֲשָׁנִים שֶׁלָּהֶם נִתְבַּשְּׁלִים הֵיטֵב, וְנַעֲשֶׂה מֵהֶם מַחֲשָׁבוֹת שִׂכְלִיּוֹת, אֲבָל מֵחֲמַת שֶׁ[[שִּׂכְלָם יוֹתֵר מִמַּעֲשֵׂיהֶם]] הַטּוֹבִים, בְּחִינַת (אבות פ"ג): כָּל שֶׁ[[חָכְמָתוֹ מְרֻבָּה מִמַּעֲשָׁיו]]; עַל־יְדֵי־זֶה, כְּשֶׁהַמַּחֲשָׁבָה שִׂכְלִיּוֹת חוֹזֶרֶת אֶל לִבָּם, אֵין כֹּחַ בְּלִבָּם לְהָכִיל אֶת הַשֵּׂכֶל, כִּי עִקַּר חִזּוּק הַלֵּב, הוּא עַל־יְדֵי מַעֲשִׂים טוֹבִים. עַל־יְדֵי־זֶה הֵם בִּבְחִינוֹת (משלי יז): לִקְנוֹת חָכְמָה וְלֵב אָיִן; וְעַל־יְדֵי זֶה הַשֵּׂכֶל הֵם מַחֲטִיאִים, וְהֵן הֵן הַ[[פִילוֹסוֹפ]]ִים, שֶׁאֵין לָהֶם לֵב טוֹב וְטָהוֹר, וְאֵינָם בִּבְחִינַת (תהלים קיט): בְּלִבִּי צָפַנְתִּי אִמְרָתֶךָ לְמַעַן לֹא אֶחֱטָא לָךְ, וּמַחֲמַת זֶה הַשֵּׂכֶל מַחֲטִיאִים בְּיוֹתֵר.
> **English:** As for short people, their vapors develop well and become intelligent thoughts. However, because their [[intellects surpass their good deeds]]—the aspect of “he whose [[wisdom is greater than his deeds” (Avot 3:9)—when the intelligent thoughts returns to their hearts, their hearts lack the strength to contain the intelligence, because the heart’s strength comes mainly from good deeds]]. As a result, they are in the aspect of “Will he purchase wisdom, when the heart is lacking” (Proverbs 17:16). And because of this intelligence they cause [others] to sin. It is they, the [[philosoph]]ers, who lack a good and pure heart, and are not in the aspect of “I have stored Your word in my heart, in order that I not sin against You” (Psalms 119:11). Thus, as a result of this intelligence, they are the primary cause of [others] sinning.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Frames intellect without adequate deeds as dangerous.

### ann_0099 — Likutei Moharan I, Lesson 55, segment 6.4
**Labels:** CRITIQUE_PHILOSOPHY
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְהֵן, בְּחִינַת (מלכים־א ה): אֵזוֹב הַיּוֹצֵא בַּקִּיר. אֵזוֹב, זֶה בְּחִינַת קְטַנֵּי קוֹמָה, הֵם בַּעֲלֵי הַשֵּׂכֶל, אֲבָל הַלֵּב אֵינוֹ יָכוֹל לְהַצְפִּין כֹּחַ הַשֵּׂכֶל בְּתוֹכוֹ, כִּי לִבָּם חַלָּשׁ וְחָסֵר. וּבִפְרָט הַנּוֹאֲפִים, הָעוֹסְקִים בְּחָכְמַת [[פִילוֹסוֹפ]]ְיָא, שֶׁמְּאֹד מְאֹד מַזִּיק לָהֶם, כִּי לִבָּם חָסֵר, בִּבְחִינַת (משלי ו): נוֹאֵף אִשָּׁה חֲסַר לֵב. וְזֶהוּ: אֵזוֹב הַיּוֹצֵא בַּקִּיר, הַיְנוּ בְּקִירוֹת הַלֵּב, שֶׁהַשֵּׂכֶל יוֹצֵא דֶּרֶךְ קִירוֹת הַלֵּב, וְאֵין הַלֵּב יְכוֹלָה לְהָכִיל בְּתוֹכָהּ אֶת הַשֵּׂכֶל, בִּבְחִינַת: בְּלִבִּי צָפַנְתִּי וְכוּ'.
> **English:** Hence, they are the aspect of “hyssop that emerges from the wall” (1 Kings 5:13). “Hyssop” is the aspect of short people; they are intelligent, but the heart is incapable of storing within it the power of the intellect. This is because their hearts are weak and lacking, especially those who are sexually immoral, who occupy themselves with [[philosoph]]y, which causes them great harm, because their hearts are lacking, in the aspect of “One guilty of adultery lacks a heart” (Proverbs 6:32). This is the meaning of “hyssop that emerges from the wall”—i.e., the walls of the heart. The intelligence emerges by way of the walls of the heart, and the heart is incapable of containing within it the intelligence, in the aspect of “I have stored [Your word] in my heart.”

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate.

### ann_0119 — Likutei Moharan I, Lesson 63, segment 5.3
**Labels:** CRITIQUE_PHILOSOPHY, HERESY_APICORUS, FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְהַנָּחָשׁ הֵם אֵלּוּ הַ[[חֲכָמִים לְהָרַע]], הַ[[חוֹקְרִים פִילוֹסוֹפ]]ְיָא וְ[[אֶפִּיקוֹרְסוּת]], כְּמוֹ שֶׁכָּתוּב (ירמיהו ד׳:כ״ב): [[חֲכָמִים הֵמָּה לְהָרַע]] וּלְהֵטִיב לֹא יָדְעוּ; שֶׁהֵם רַק [[חֲכָמִים לְהָרַע]], שֶׁאִם יִרְצוּ לְהִשְׁתַּמֵּשׁ בְּחָכְמָתָם לְהֵיטִיב לֹא יוּכְלוּ. וְהֵם בְּחִינוֹת הַנָּחָשׁ, בְּחִינוֹת (בראשית ג׳:א׳): וְהַנָּחָשׁ הָיָה עָרוּם מִכֹּל חַיּוֹת הַשָּׂדֶה.
> **English:** Now, the serpent signifies those scholars at doing evil who study [[philosoph]]y and [[heretical]] teachings, as it is written (Jeremiah 4:22), “they are [[wise to do evil]], but to do good they have no knowledge.” They are scholars only at doing evil; if they should want to use their wisdom for good, they could not. They are the aspect of the serpent, the aspect of “Now the serpent was the most cunning of all the wild beasts” (Genesis 3:1) .

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Connects the issue to apikorsut/heresy rather than neutral intellectual life. Critiques false or evil wisdom, not wisdom as such.

### ann_0131 — Likutei Moharan I, Lesson 64, segment 2.5
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, LIMITS_OF_HUMAN_INTELLECT
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** כֵּן יֵשׁ כַּמָּה מְבוּכוֹת וְקֻשְׁיוֹת אֵצֶל הַ[[מְּחַקְּרִים]], שֶׁבֶּאֱמֶת אֵינָם שׁוּם חָכְמָה, וְהַקֻּשְׁיוֹת בְּטֵלִים מֵעִקָּרָא, אַךְ מֵחֲמַת שֶׁ[[אֵין בְּהַשֵּׂכֶל אֱנוֹשִׁי]] לְיַשְּׁבָם, עַל־יְדֵי־זֶה נִדְמִים לְחָכְמוֹת וְקֻשְׁיוֹת.
> **English:** Likewise, the [[philosoph]]ers have a number of conundrums and questions that in fact have no [basis in] wisdom, and the questions are nullified from the outset, but since the human mind is incapable of answering them they consequently seem to be [based in] wisdom and [to raise legitimate] questions.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Draws a boundary around human intellect.

### ann_0134 — Likutei Moharan I, Lesson 64, segment 2.8
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, FAITH_OVER_INQUIRY, HERESY_APICORUS
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** רַק יִשְׂרָאֵל עַל־יְדֵי [[אֱמוּנָה עוֹבְרִים עַל כָּל הַחָכְמוֹת, וַאֲפִלּוּ עַל הָאֶפִּיקוֹרְסוּת הַזֹּאת הַבָּא מֵחָלָל הַפָּנוּי, כִּי הֵם מַאֲמִינִים בְּהַשֵּׁם יִתְבָּרַךְ בְּלִי שׁוּם חֲקִירָה]] וְחָכְמָה, רַק בֶּאֱמוּנָה שְׁלֵמָה.
> **English:** But through faith, the Jewish people prevail over all the wisdoms and even this [[heresy]] that stems from the Vacated Space. This is because they believe in God, without any [[philosophical enquiry]] and intellection, but only with perfect faith.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Places faith, mitzvot, or simplicity above inquiry as the path to religious completion. Connects the issue to apikorsut/heresy rather than neutral intellectual life.

### ann_0136 — Likutei Moharan I, Lesson 64, segment 2.12
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** אֲבָל בֶּאֱמֶת לַאֲמִתּוֹ בְּוַדַּאי יֵשׁ עֲלֵיהֶם תְּשׁוּבָה, וּבְוַדַּאי יֵשׁ שָׁם אֱלֹקוּתוֹ יִתְבָּרַךְ. אֲבָל עַל־יְדֵי [[חֲקִירוֹת]] נִשְׁקָעִים שָׁם, כִּי אִי אֶפְשָׁר לִמְצֹא שָׁם אֶת הַשֵּׁם יִתְבָּרַךְ, מֵאַחַר שֶׁהוּא בְּחִינַת חָלָל הַפָּנוּי, רַק צְרִיכִין לְהַאֲמִין שֶׁהַשֵּׁם יִתְבָּרַךְ סוֹבֵב גַּם עָלָיו, וּבְוַדַּאי בֶּאֱמֶת גַּם שָׁם יֵשׁ אֱלֹקוּתוֹ יִתְבָּרַךְ.
> **English:** Nevertheless, the actual truth is that there surely is an answer for them, and there certainly is Godliness there. However, as a result of [[philosophical enquiry]] they become submerged there, because it is impossible to find God there since it is the aspect of the Vacated Space. Rather, a person must believe that God encircles that as well, and that in truth His Godliness is certainly there as well.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary.

### ann_0154 — Likutei Moharan I, Lesson 123, segment 1.2
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, HERESY_APICORUS, FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְיִשְׂרָאֵל בְּעֵת קַבָּלַת הַתּוֹרָה הָיוּ לָהֶם [[חָכְמוֹת גְּדוֹלוֹת, כִּי אָז הָיוּ עוֹבְדֵי עֲבוֹדָה זָרָה שֶׁבִּימֵיהֶם, שֶׁהָיָה טָעוּתָם]] עַל־פִּי חָכְמוֹת וַ[[חֲקִירוֹת]] גְּדוֹלוֹת כַּיָּדוּעַ. וְלוּלֵי שֶׁהָיוּ יִשְׂרָאֵל מַשְׁלִיכִין מֵעַצְמָן הַחָכְמוֹת, לֹא הָיוּ מְקַבְּלִים הַתּוֹרָה. כִּי הָיוּ יְכוֹלִים לִכְפֹּר בַּכֹּל, חַס וְשָׁלוֹם, וְלֹא הָיָה מוֹעִיל לָהֶם כָּל מַה שֶּׁעָשָׂה מֹשֶׁה רַבֵּנוּ עִמָּהֶם. וַאֲפִלּוּ כָּל הָאוֹתוֹת וְהַמּוֹפְתִים הַנּוֹרָאִים שֶׁעָשָׂה לְעֵינֵיהֶם, לֹא הָיָה מוֹעִיל לָהֶם, כִּי גַּם עַתָּה נִמְצָאִים [[אֶפִּיקוֹרְס]]ִים הַכּוֹפְרִים עַל־יְדֵי שְׁטוּת וְטָעוּת חָכְמָתָם.
> **English:** When the Jewish people received the Torah, they possessed great pseudo-wisdoms. For then, the mistakes of those who served idolatry at that time stemmed from great pseudo-wisdoms and [[philosoph]]ies, as is known. Had Israel not cast off from themselves the pseudo-wisdoms, they would not have received the Torah. They might have denied everything, God forbid. All that Moshe Rabbeinu did with them would have been of no help to them. Even all the signs and awesome wonders which he performed before their very eyes would not have helped them. Today, as well, there are [[heretic]]s who deny [God] based on the foolishness and error of their pseudo-wisdoms.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Connects the issue to apikorsut/heresy rather than neutral intellectual life. Critiques false or evil wisdom, not wisdom as such.

### ann_0164 — Likutei Moharan I, Lesson 216, segment 1.1
**Labels:** CRITIQUE_PHILOSOPHY, ANTI_NATURALISM
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** דַּע, כִּי הַ[[פִילוֹסוֹפ]]ִים קוֹרִים לְהַטֶּבַע אֵם כָּל חָי, וַאֲנַחְנוּ עַל יְדֵי תְּפִלּוֹתֵינוּ אָנוּ [[מְבַטְּלִים הַטֶּבַע]], כִּי הַטֶּבַע מְחַיֵּב כָּךְ, וְעַל יְדֵי הַתְּפִלָּה נִשְׁתַּנֶּה הַטֶּבַע.
> **English:** Know! the [[philosophers call nature]] Em Kol Chay (Mother Nature). We, with our prayers, [[nullify nature]]. For nature necessitates such-and-such, and through prayer [the course of] nature is changed.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Rejects naturalistic explanation where it undermines miracles, prayer, or providence.

### ann_0186 — Likutei Moharan II, Lesson 5, segment 15.23
**Labels:** SIMPLICITY_PSHITUT, PRACTICE_OVER_STUDY
**Stance:** supports qualified anti-intellectual reading | **Score:** 4

> **Hebrew:** כִּי בֶּאֱמֶת צְרִיכִין דַיְקָא [[לְסַלֵּק אֶת הַמֹּח]]ַ, כִּי צְרִיכִין [[לְהַשְׁלִיךְ כָּל הַחָכְמוֹת]] וְלַעֲבֹד אֶת ה' בִּ[[פְשִׁיטוּת]], כִּי צָרִיךְ שֶׁיִּהְיוּ [[מַעֲשָׂיו מְרֻבִּין מֵחָכְמָתו]]ֹ (אבות פ"ג), וְלֹא הַמִּדְרָשׁ הוּא הָעִקָּר, אֶלָּא הַמַּעֲשֶׂה (שם פ"א), וְעַל כֵּן צְרִיכִין לְסַלֵּק כָּל הַחָכְמוֹת וְלַעֲבֹד אֶת ה' בִּ[[פְשִׁיטוּת]], [[בְּלִי שׁוּם חָכְמוֹת]]. לֹא מִבָּעֲיָא חָכְמוֹת שֶׁל שְׁטוּת שֶׁל סְתַם בְּנֵי אָדָם, אֶלָּא אֲפִלּוּ חָכְמוֹת גְּמוּרוֹת, אֲפִלּוּ מִי שֶׁיֵּשׁ לוֹ מֹחַ גָּדוֹל בֶּאֱמֶת, כְּשֶׁמַּגִּיעַ לְאֵיזֶה עֲבוֹדָה, הוּא צָרִיךְ [[לְהַשְׁלִיךְ כָּל הַחָכְמוֹת]] וְלַעֲסֹק בַּעֲבוֹדָתוֹ יִתְבָּרַךְ בִּ[[פְשִׁיטוּת]].
> **English:** In truth, it is particularly necessary to [[set aside the mind]]. People have to [[discard all sophisticated ideas]] and serve God with [[simplicity]]. A person’s [[practices should exceed his scholarship]] (Avot 3:9) ; action is the main thing, not the study (ibid. 1:17). It is therefore necessary to set aside all wisdom, and to worship God with [[simplicity]], [[without any sophisticated ideas]]. This is obviously so for the foolish “wisdom” of the average person, but even applies to genuine wisdom. When it comes to serving God, even someone who in truth has a great mind, must [[discard all sophisticated ideas]] and serve Him with [[simplicity]].

**Note:** Elevates temimut/pshittut—simple, unsophisticated service of God. Subordinates study or discourse to concrete practice.

### ann_0199 — Likutei Moharan II, Lesson 12, segment 1.2
**Labels:** SIMPLICITY_PSHITUT
**Stance:** supports qualified anti-intellectual reading | **Score:** 3

> **Hebrew:** וְעִקָּר הַיַּהֲדוּת הוּא רַק לֵילֵךְ בִּ[[תְמִימוּת]] וּבִ[[פְשִׁיטוּת]], [[בְּלִי שׁוּם חָכְמוֹת]], וּלְהִסְתַּכֵּל בְּכָל דָּבָר שֶׁעוֹשֶׂה, שֶׁיִּהְיֶה שָׁם הַשֵּׁם יִתְבָּרַךְ, וְלִבְלִי לְהַשְׁגִּיחַ כְּלָל עַל כְּבוֹד עַצְמוֹ. רַק אִם יֵשׁ בָּזֶה כְּבוֹד הַשֵּׁם יִתְבָּרַךְ יַעֲשֶׂה, וְאִם לָאו – לָאו, וַאֲזַי בְּוַדַּאי לֹא יִכָּשֵׁל לְעוֹלָם.
> **English:** The essence of Judaism is to conduct oneself solely with innocence and [[simplicity]], without any sophistication. A person has to ascertain that God is present in whatever he does, without any concern whatsoever for his own esteem. He should do it only if it brings glory to God; but if not, not. This way he will certainly never stumble.

**Note:** Elevates temimut/pshittut—simple, unsophisticated service of God.

### ann_0208 — Likutei Moharan II, Lesson 19, segment 1.1
**Labels:** SIMPLICITY_PSHITUT
**Stance:** supports qualified anti-intellectual reading | **Score:** 3

> **Hebrew:** עִקָּר הַתַּכְלִית וְהַשְּׁלֵמוּת הוּא רַק לַעֲבֹד הַשֵּׁם בִּ[[תְמִימוּת]] גָּמוּר, [[בְּלִי שׁוּם חָכְמוֹת]] כְּלָל.
> **English:** The ultimate goal and perfection is nothing other than to serve God with absolute [[simplicity]], without any cleverness whatsoever.

**Note:** Elevates temimut/pshittut—simple, unsophisticated service of God.

### ann_0211 — Likutei Moharan II, Lesson 19, segment 1.4
**Labels:** FAITH_OVER_INQUIRY, SIMPLICITY_PSHITUT, PRACTICE_OVER_STUDY
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** אֲבָל בֶּאֱמֶת אֶצְלֵנוּ עִקָּר הַשָּׂגַת הַתַּכְלִית הוּא [[רַק עַל־יְדֵי אֱמוּנָה וּמִצְווֹת מַעֲשִׂיּוֹת]], לַעֲבֹד הַשֵּׁם עַל־פִּי הַתּוֹרָה בִּ[[תְמִימוּת]] וּבִ[[פְשִׁיטוּת]]. וְעַל־יְדֵי־זֶה בְּעַצְמוֹ זוֹכִין לְמַה שֶּׁזּוֹכִין, עַיִן לֹא רָאָתָה וְכוּ', כְּמוֹ שֶׁכָּתוּב (תהילים קי״א:י׳): רֵאשִׁית חָכְמָה יִרְאַת ה' – שֶׁעִקָּר רֵאשִׁית וּקְדִימַת הַחָכְמָה הוּא רַק יִרְאַת ה', שֶׁצָּרִיךְ לְהַקְדִּים הַיִּרְאָה לְהַחָכְמָה.
> **English:** However, in fact, we regard the attainment of the ultimate goal to be essentially only through faith and applied mitzvot—worshiping God based on the Torah, with [[simplicity]] and straightforwardness. And through this itself we merit that which we merit, “no eye has seen it…” (Isaiah 64:3), as it is written (Psalms 111:10): “The beginning of wisdom is the fear of God.” The main genesis and preface to wisdom is nothing but the fear of God. One must make certain that the fear precedes the wisdom.

**Note:** Places faith, mitzvot, or simplicity above inquiry as the path to religious completion. Elevates temimut/pshittut—simple, unsophisticated service of God. Subordinates study or discourse to concrete practice.

### ann_0212 — Likutei Moharan II, Lesson 19, segment 1.5
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְתֵדַע שֶׁאֵין הַדָּבָר כְּדַעְתָּם, חַס וְשָׁלוֹם, כִּי אִם־כֵּן לֹא יַשִּׂיגוּ הַתַּכְלִית, רַק מְתֵי מְעַט מְעַט מְאֹד, דְּהַיְנוּ הַבַּעֲלֵי־שֵׂכֶל [[פִילוֹסוֹפ]]ִים, וּמַה יַּעֲשׂוּ קְטַנֵּי הָעֵרֶךְ, שֶׁ[[אֵין לָהֶם שֵׂכֶל כָּזֶה לַחֲקֹר]] [[חֲקִירוֹת]], לָדַעַת הַמֻּשְׂכָּלוֹת, שֶׁהֵם רֹב וְעִקָּר הָעוֹלָם, אֵיךְ יַשִּׂיגוּ הֵם אֶת הַתַּכְלִית.
> **English:** And you should know that the matter is not as they maintain, God forbid. For if it were so, then only very, very few—namely, the intellectually elite [[philosoph]]ers—would attain the ultimate goal. Then what of the ordinary folk, who lack the mind for engaging in [[philosophical enquiry]] to know the necessary truths? They are the majority and the nucleus of the world. How would they attain the ultimate goal?

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary.

### ann_0213 — Likutei Moharan II, Lesson 19, segment 1.6
**Labels:** SIMPLICITY_PSHITUT, PRACTICE_OVER_STUDY
**Stance:** supports qualified anti-intellectual reading | **Score:** 4

> **Hebrew:** אֲבָל בֶּאֱמֶת עִקָּר הַשָּׂגַת הַתַּכְלִית הוּא רַק עַל־יְדֵי [[תְּמִימוּת]] דַּיְקָא, דְּהַיְנוּ יִרְאַת־הַשֵּׁם וּ[[מִצְווֹת מַעֲשִׂיּוֹת]] בִּ[[פְשִׁיטוּת]] גָּמוּר. וְזֶהוּ (סוף קהלת): סוֹף דָּבָר הַכֹּל נִשְׁמָע, אֶת הָאֱלֹֹקִים יְרָא וְאֶת מִצְו‍ֹתָיו שְׁמוֹר, כִּי זֶה כָּל הָאָדָם; הַיְנוּ שֶׁשְּׁלֹמֹה הַמֶּלֶךְ, עָלָיו הַשָּׁלוֹם, מְלַמֵּד אוֹתָנוּ, שֶׁעִקָּר הַשָּׂגַת הַתַּכְלִית, שֶׁהוּא בְּחִינַת סוֹף דָּבָר, הוּא רַק עַל־יְדֵי [[תְּמִימוּת]] וּ[[פְשִׁיטוּת]], לְיִרְאָה אֶת ה' וְלִשְׁמֹר מִצְוו‍ֹתָיו בִּ[[פְשִׁיטוּת]].
> **English:** But in fact, attainment of the ultimate goal is specifically through [[simplicity]]—i.e., fear of God, and [fulfilling] the applied mitzvot with total straightforwardness. This is the meaning of “Ultimately, all things having been considered: Fear the Lord and keep His commandments! For this is [the sum of] all mankind” (Ecclesiastes 12:13). In other words, King Shlomo, of blessed memory, teaches us that the attainment of the ultimate goal, the concept of “Ultimately,” is essentially only by means of [[simplicity]] and straightforwardness—to fear God and observe His mitzvot straightforwardly.

**Note:** Elevates temimut/pshittut—simple, unsophisticated service of God. Subordinates study or discourse to concrete practice.

### ann_0226 — Likutei Moharan II, Lesson 44, segment 1.3
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, SIMPLICITY_PSHITUT
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וּכְבָר מְבֹאָר בִּסְפָרִים וּבִדְבָרֵינוּ בְּכַמָּה מְקוֹמוֹת, לְהַרְחִיק עַצְמוֹ מְאֹד מְאֹד לִבְלִי לְעַיֵּן כְּלָל בְּסִפְרֵי הַ[[מְחַקְרִים]] הַ[[פִילוֹסוֹפ]]ְיָא, וַאֲפִלּוּ מִסְּפָרִים שֶׁל [[חַקִירָה]] שֶׁחִבְּרוּ גְּדוֹלִים מֵאַחֵינוּ בְּנֵי יִשְׂרָאֵל, גַּם מֵהֶם צָרִיךְ לְהַרְחִיק מְאֹד, כִּי הֵם מַזִּיקִים מְאֹד לָאֱמוּנָה, כִּי דַּי לָנוּ בֶּאֱמוּנָתֵנוּ שֶׁקִּבַּלְנוּ מֵאֲבוֹתֵינוּ הַקְּדוֹשִׁים. וְזֶה כְּלָל גָּדוֹל וִיסוֹד וְעִקָּר בַּעֲבוֹדַת הַשֵּׁם – לִהְיוֹת תָּם וְיָשָׁר וְכוּ', לַעֲבֹד אוֹתוֹ יִתְבָּרַךְ בִּ[[תְמִימוּת]], [[בְּלִי שׁוּם חָכְמוֹת]] וַ[[חֲקִירוֹת]] כְּלָל כְּלָל לֹא.
> **English:** Now, it has already been explained in holy books, and in various places in our teachings, that one has to stay very far away from any study of the works of the [[philosoph]]ers. One has to greatly distance oneself even from the [[philosoph]]ical works authored by leading figures among our Jewish brethren. Such works are very damaging to faith. For our faith, which we received from our holy ancestors, is enough for us. This is a major rule and a fundament and the essence of serving God: To be simple and upright…, to serve God with [[simplicity]], without any cleverness or [[philosoph]]ical speculation—none at all.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Elevates temimut/pshittut—simple, unsophisticated service of God.

### ann_0210 — Likutei Moharan II, Lesson 19, segment 1.3
**Labels:** CRITIQUE_EXTERNAL_WISDOM, CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** כִּי יֵשׁ מַשְׂכִּיל וּמֻשְׂכָּל וְשֵׁכֶל, דְּהַיְנוּ הַכֹּחַ הַמַּשְׂכִּיל, וְהַשֵּׂכֶל בְּעַצְמוֹ, וְהַדָּבָר הַמֻּשְׂכָּל, וְזֶהוּ הַתַּכְלִית וְהָעוֹלָם הַבָּא אֶצְלָם, שֶׁיִּהְיֶה נַעֲשֶׂה אֶחָד מֵהַמַּשְׂכִּיל וְהַמֻשְׂכָּל וְהַשֵּׂכֶל, וְהֵם מְבַלִּים יְמֵיהֶם עַל זֶה בָּעוֹלָם הַזֶּה לַחֲקֹר וּלְהַשִּׂיג הַמֻּשְׂכָּלוֹת, שֶׁזֶּהוּ הַתַּכְלִית אֶצְלָם, וְזֶהוּ בְּעַצְמוֹ הָעוֹלָם הַבָּא לְדַעְתָּם. רַק שֶׁבָּעוֹלָם הַזֶּה שֶׁמְּלֻבָּשִׁין בְּגוּף, אֵין לָהֶם תַּעֲנוּג כָּל־כָּךְ מִן הַ[[חֲקִירוֹת]], וּבָעוֹלָם הַבָּא שֶׁיִּתְפַּשְּׁטוּ מֵהַגּוּף, יִתְעַנְּגוּ מְאֹד מִזֶּה. וּלְ[[דַעְתָּם הָרָעָה]], עִקָּר הַשָּׂגַת הַתַּכְלִית הוּא עַל־יְדֵי [[חֲקִירוֹת]] וְ[[חָכְמוֹת חִיצוֹנִיּוֹת]] שֶׁלָּהֶם.
> **English:** For there is the knower, the known and the knowledge—i.e., the ability of the knower, the intellect itself, and the known object. For [the [[philosoph]]ers,] it is this which is the ultimate goal and the World to Come: that the knower, the known and the knowledge become one. They spend all their days in this world on this, engaging in [[philosophical enquiry]] to attain the necessary truths, which they regard as the ultimate goal. In their opinion, this itself is the World to Come. Notwithstanding that in this world, enclothed as they are in corporeality, the delight which they have from this [[philosophical enquiry]] is minimal, in the World to Come, where they will strip away the body, they will have great delight from this. Thus, according to their nefarious ideas, the ultimate goal is primarily attained by means of their [[philosoph]]y and secular wisdoms.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Critiques external wisdom and treats it as something that can contaminate or distract the mind. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Critiques false or evil wisdom, not wisdom as such.

### ann_0217 — Likutei Moharan II, Lesson 19, segment 2.5
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, FAITH_OVER_INQUIRY, PRACTICE_OVER_STUDY
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְזֶה שֶׁכָּתוּב בְּמשֶׁה רַבֵּנוּ (שמות י״ז:י״ב): וַיְהִי יָדָיו אֱמוּנָה, בְּמִלְחֶמֶת עֲמָלֵק, כִּי עַל־יְדֵי אֱמוּנָה הֶחֱלִישׁ אֶת עֲמָלֵק, דְּהַיְנוּ הַחָכְמוֹת וְהַ[[חֲקִירוֹת]] כַּנַּ"ל. וְזֶה: וַיְהִי יָדָיו אֱמוּנָה. יָדָיו – הַיְנוּ בְּחִינַת [[מִצְווֹת מַעֲשִׂיּוֹת]], שֶׁהֵם בְּחִינַת אֱמוּנָה, כְּמוֹ שֶׁכָּתוּב (תהילים קי״ט:פ״ו): כָּל מִצְו‍ֹתֶיךָ אֱמוּנָה. שֶׁ[[עַל־יְדֵי אֱמוּנָה וּמִצְווֹת מַעֲשִׂיּוֹת]], שֶׁהֵם הֶפֶךְ בְּחִינַת עֲמָלֵק, הֶחֱלִישׁוֹ כַּנַּ"ל.
> **English:** This is what is written about Moshe Rabbeinu during the war with Amalek (Exodus 17:12) :“thus his hands were faith.” Through faith he weakened Amalek, i.e., the wisdoms and the [[philosoph]]ical enquiries, as mentioned above. And this is “and his hands were faith.” “His hands” alludes to the applied mitzvot, which correspond to faith, as it is written (Psalms 119:86), “All Your mitzvot are faith.”Through faith and applied mitzvot, which are the antithesis of Amalek, he weakened him.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Places faith, mitzvot, or simplicity above inquiry as the path to religious completion. Subordinates study or discourse to concrete practice.

### ann_0120 — Likutei Moharan I, Lesson 63, segment 5.4
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, HERESY_APICORUS, FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְעַל־יְדֵי דִּבּוּרִים רָעִים, עוֹשִׂים כְּנָפַיִם לְהַחֲכָמִים אֵלּוּ, שֶׁהֵם בְּחִינַת הַנָּחָשׁ, שֶׁיּוּכְלוּ לָעוּף וְלִפְרֹחַ, הַיְנוּ שֶׁמְּעוֹפֶפֶת וּמִתְפַּשֶּׁטֶת חָכְמָתָם וְ[[אֶפִּיקוֹרְס]]ִית שֶׁלָּהֶם בָּעוֹלָם, וּמַזִּיק מְאֹד לְהָעוֹלָם. וְגַם בַּ[[חֲקִירוֹת]]ָם בְּעַצְמָם הֵם מְעוֹפְפִים, כְּמוֹ מִי שֶׁיֵּשׁ לוֹ שֵׂכֶל מְעוֹפֵף, הַיְנוּ שֶׁשִּׂכְלָם מְעוֹפֵף בִּמְהִירוּת, וְנִפְתָּח לָהֶם חָכְמָתָם מְאֹד.
> **English:** By means of the evil words, wings are made for these scholars, who are the aspect of the serpent, so that they can fly about—i.e., so that [[their scholarship]] and [[heretical]] teachings fly and spread around the world, causing it much harm. And even in their [[philosophical investigation]] itself they fly about, like someone with a flying intellect—i.e., their intellect flies at a <great> speed, and their wisdom is very accessible to them.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Connects the issue to apikorsut/heresy rather than neutral intellectual life. Critiques false or evil wisdom, not wisdom as such.

### ann_0219 — Likutei Moharan II, Lesson 19, segment 3.1
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, PRACTICE_OVER_STUDY, HERESY_APICORUS
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְהַ[[מְחַקְּרִים]] וְהַכּוֹפְרִים מְפָרְשִׁים כָּל הַתּוֹרָה כֻּלָּהּ עַל־פִּי חָכְמוֹת וְ[[אֶפִּיקוֹרְסוּת]] שֶׁלָּהֶם, שֶׁכָּל הַתּוֹרָה, וַאֲפִלּוּ [[מִצְווֹת מַעֲשִׂיּוֹת]] הַכְּתוּבִים בַּתּוֹרָה, מְפָרְשִׁים הַכֹּל עַל־פִּי צוּרָה וָשֵׂכֶל; לָא מִבָּעֲיָא מַעֲשִׂיּוֹת הַכְּתוּבִים בַּתּוֹרָה, אוֹמְרִים שֶׁהֵם מְרַמְּזִים רַק עַל הַנִּמְשָׁל וְהַצּוּרָה לְבַד, דְּהַיְנוּ שִׂכְלִיּוּת שֶׁלָּהֶם, אֶלָּא אֲפִלּוּ [[מִצְווֹת מַעֲשִׂיּוֹת]] הַמְפֹרָשִׁים בַּתּוֹרָה, מְפָרְשִׁים הַכֹּל שֶׁהֵם מְרַמְּזִים רַק עַל שִׂכְלִיּוּת וְחָכְמוֹת שֶׁלָּהֶם, וְכוֹפְרִים בִּפְשׁוּטוֹ לְגַמְרֵי.
> **English:** 3. But the [[philosoph]]ers and nonbelievers explain the entire Torah according to their wisdoms and heresies. They interpret everything, the entire Torah and even the applied mitzvot recorded in the Torah, based on abstraction and logic. Not only is this the case with the stories recorded by Scripture, which they say refer solely to allegory and form—i.e., their intellectual concepts—but even the applied mitzvot specified in the Torah. They interpret everything as alluding solely to their intellectual concepts and wisdoms, and deny the straightforward meaning entirely.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Subordinates study or discourse to concrete practice. Connects the issue to apikorsut/heresy rather than neutral intellectual life.

### ann_0122 — Likutei Moharan I, Lesson 63, segment 5.6
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְגַם בֵּינָם לְבֵין עַצְמָן אֵין שִׂכְלָם מְעוֹפֵף, הַיְנוּ שֶׁאֵין נִפְתָּח לָהֶם הַחָכְמָה כָּל־כָּךְ, וְאֵינָם מְעוֹפְפִים וּמְהִירִים בַּחָכְמוֹת שֶׁלָּהֶם, רַק חוֹקְרִים בְּחָכְמָתָם מְעַט מְעַט, כְּמוֹ הַהוֹלֵךְ. וְגַם מַה שֶּׁמַּזִּיקִים לַאֲחֵרִים בְּחָכְמָתָם הוּא רַק בִּבְחִינַת הֲלִיכָה, שֶׁאֵינוֹ מְעוֹפֵף וְנִכְנָס בָּעֹמֶק לְתוֹךְ הַמֹּחַ וְהַלֵּב, רַק שֶׁנִּדְבָּק קְצָת לְהַמֹּחַ, אֲבָל אֵינוֹ נִכְנָס בָּעֹמֶק לְתוֹךְ הַלֵּב וְהַמֹּחַ.
> **English:** Even among themselves, their intellect does not fly—i.e., their <heart and wisdom are> not so very accessible to them. Thus they do not fly about and move swiftly in [[their scholarship]], but engage in [[philosophical investigation]] gradually, like someone walking. Therefore, the harm they bring to others through [[their scholarship]] is also only in the aspect of walking; it does not fly about and enter deeply into the mind and heart. Rather, it only somewhat adheres to the mind, without entering deeply into the heart and mind.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Critiques false or evil wisdom, not wisdom as such.

### ann_0126 — Likutei Moharan I, Lesson 63, segment 7.8
**Labels:** CRITIQUE_PHILOSOPHY, CRITIQUE_SPECULATIVE_INQUIRY, FALSE_WISDOM_CRITIQUE
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** שָׁארֵי בְּחִבּוּרָא וְסַיֵּם בְּפֵרוּדָא, הַיְנוּ שֶׁאֵלּוּ הַ[[מְּחַקְּרִים]], שֶׁהֵם [[חֲכָמִים לְהָרַע]], שֶׁהֵם בְּחִינוֹת הַנָּחָשׁ כַּנַּ"ל, חָכְמָתָם וַ[[חֲקִירָתָם]] הוּא – שָׁארֵי בְּחִבּוּרָא, שֶׁתְּחִלַּת [[חֲקִירָתָם]] מַתְחֶלֶת מֵהַמְחֻבָּרִים, מֵחִבּוּר חֹמֶר וְצוּרָה. וְסַיֵּם בְּפֵרוּדָא, שֶׁמִּסְתַּיֶּמֶת חָכְמָתָם בַּשִּׂכְלִיִּים הַנִּפְרָדִים.
> **English:** It starts out attached, but ends up separated—That is, these [[philosoph]]ers—who are scholars at doing evil, which is the aspect of the serpent, as explained above—<all> [[their scholarship]] and [[philosophical investigation]] “starts out attached.” Their [[investigation]] starts with that which is attached, with the bond between matter and form. “But ends up separated”—[[their scholarship]] concludes at the separate intelligences.

**Note:** Explicitly marks philosophy/philosophers as spiritually problematic or inadequate. Warns against investigation/speculative inquiry when it exceeds the proper boundary. Critiques false or evil wisdom, not wisdom as such.

### ann_0195 — Likutei Moharan II, Lesson 8, segment 8.8
**Labels:** FAITH_OVER_INQUIRY, HERESY_APICORUS, LIMITS_OF_HUMAN_INTELLECT
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** כִּי עִקָּר חִדּוּשׁ הָעוֹלָם, דְּהַיְנוּ לֵידַע שֶׁהָעוֹלָם מְחֻדָּשׁ וְהַשֵּׁם יִתְבָּרַךְ בָּרָא אֶת הָעוֹלָם בִּרְצוֹנוֹ, הוּא תָּלוּי בֶּאֱמוּנָה, כִּי עַל־יְדֵי שֵׂכֶל [[אִי אֶפְשָׁר לְהָבִין חִדּוּשׁ הָעוֹלָם, וְעַל־כֵּן הָאֶפִּיקוֹרְסִים כּוֹפְרִים בָּזֶה, מֵחֲמַת שֶׁאִי אֶפְשָׁר לְהָבִין זֹאת בַּשֵּׂכֶל]]. כִּי עִקָּר חִדּוּשׁ הָעוֹלָם הוּא [[רַק עַל־יְדֵי אֱמוּנָה]], כִּי אָנוּ מַאֲמִינִים בַּה' שֶׁהוּא יִתְבָּרַךְ בָּרָא אֶת הָעוֹלָם מֵחָדָשׁ. כִּי בֶּאֱמֶת חִדּוּשׁ הָעוֹלָם הָיָה עַל־יְדֵי בְּחִינַת אֱמוּנָה, כְּמוֹ שֶׁכָּתוּב (תהילים ל״ג:ד׳): וְכָל מַעֲשֵׂהוּ בֶּאֱמוּנָה. נִמְצָא שֶׁעִקָּר חִדּוּשׁ הָעוֹלָם תָּלוּי בֶּאֱמוּנָה.
> **English:** The essence of chidush haolam—i.e., knowing that the world is ex nihilo and that God created it by an act of His Will—is dependent upon faith. For it is impossible to intellectually comprehend the origination of the world. And because the intellect cannot comprehend it, unbelievers refuse to believe it. The essence of the chidush of the world is only through faith: our faith in God that He created the world ex nihilo. For, in truth, the world’s origination occurred through faith, as it is written, “and all His work is done with faith” (Psalms 33:4). It follows, that the essence of the world’s renewal depends upon faith.

**Note:** Places faith, mitzvot, or simplicity above inquiry as the path to religious completion. Connects the issue to apikorsut/heresy rather than neutral intellectual life. Draws a boundary around human intellect.

### ann_0242 — Likutei Moharan II, Lesson 78, segment 7.5
**Labels:** FAITH_OVER_INQUIRY, SIMPLICITY_PSHITUT
**Stance:** supports qualified anti-intellectual reading | **Score:** 5

> **Hebrew:** וְצָרִיךְ לְחַזֵּק עַצְמוֹ בְּיִרְאַת־שָׁמַיִם גַּם בְּעֵת [[פְּשִׁיטוּת]]וֹ בְּכָל מַה שֶּׁיּוּכַל, וְיוּכַל לָבוֹא לְשִׂמְחָה גְדוֹלָה עַל־יְדֵי [[תְּמִימוּת]]וֹ וֶאֱמוּנָתוֹ. כִּי חָכְמוֹת אֵין צְרִיכִין כְּלָל, רַק [[אֱמוּנָה וּתְמִימוּת וּפְשִׁיטוּת בְּלִי שׁוּם חָכְמָה]] כְּלָל. כִּי חָכְמוֹת מַזִּיקִים מְאֹד לְהָאָדָם, וְהַחֲכָמִים נִלְכָּדִים בְּחָכְמָתָן שֶׁל עַצְמָם, כִּי הַחָכְמָה מַתְעָה אוֹתוֹ מֵחָכְמָה לְחָכְמָה, וּמֵאוֹתָהּ הַחָכְמָה לְחָכְמָה אַחֶרֶת, וְכֵן מֵחָכְמָה לְחָכְמָה יוֹתֵר וְיוֹתֵר, עַד שֶׁנִּלְכָּד וְנִתְעֶה בְּחָכְמוֹת עַצְמוֹ, בִּבְחִינַת (איוב ה׳:י״ג): לֹכֵד חֲכָמִים בְּעָרְמָם – בְּעָרְמָם דַּיְקָא, הַיְנוּ בְּעַרְמִימוּת וְחָכְמוֹת שֶׁלָּהֶם בְּעַצְמָם הוּא לוֹכֵד אוֹתָם. אַשְׁרֵי הַהוֹלֵךְ בִּ[[תְמִימוּת]]:
> **English:** And in whatever way he can he has to encourage himself with fear of Heaven also while in a state of [[simplicity]]. He can then attain great joy through his [[simplicity]] and his faith. For sophistication is altogether unnecessary; only faith, straightforwardness and [[simplicity]], without any sophistication whatsoever. This is because sophistication is very harmful for a person, and sophisticated individuals get caught in their own sophistication. For sophistication leads him astray, from one sophisticated idea to the next, and from that sophisticated idea to another, and likewise to more and more sophisticated ideas until he becomes trapped and is led astray by his own sophistication, as in “He traps the sophisticated by their own cleverness” (Job 5:13). Specifically “by their own cleverness”—i.e., by the cleverness and sophistication which they themselves possess, He traps them. Pra…

**Note:** Places faith, mitzvot, or simplicity above inquiry as the path to religious completion. Elevates temimut/pshittut—simple, unsophisticated service of God.

## Strongest counterevidence / balancing passages

### ann_0001 — Introduction, segment 3
**Labels:** COUNTER_DEEP_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** דרך כמה צמצומים והשתלשלות מעלה לעלול משכל עליון לשכל תחתון. עד אשר נתלבשו בלבושין האלו בחלוקא דרבנן. בדרך צחות ונאות. ובדרושים ערבים ונפלאים ומתוקים לחך. בדרך [[חכמה וטעם ופלפול וסברא]] ודרך חיים תוכחות מוסר השכל הבוער כאש עד לב השמים.
> **English:** [These teachings are taught to us] through numerous constrictions and diminutions—from the Cause of Causes to the caused, from the upper intellect to the lower one (see Lesson #30)—until they have become clothed in these garments, the cloak of the Sages, in a clear and beautiful manner. They are in the form of pleasant, wondrous and sweet discourses, in the way of [[wisdom, reason, dialectic and logic]], and the way of life—the reproof of ethical instruction, which is like a fire that burns to the very heart of heaven.

**Note:** Counterbalance: praises depth, reasoning, proofs, or careful study.

### ann_0005 — Introduction, segment 29
**Labels:** COUNTER_DEEP_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** וצריך אתה המעין שתבין בדבריו שלפעמים מביא שנים או שלש ראיות לדבר אחד. בדרך עמקות נפלא ונעים מאד. ומרהיטת הלשון נדמה כאלו היא ראיה אחת. כי כך דרך הספר הזה. שכותב על-פי רב כמה פעמים תבת כי וכיוצא על דבר אחד. ומחמת זה נדמה שהוא טעם וראיה אחת. ובאמת הוא כמה וכמה טעמים. וכל אחד קשור בחברו. על-כן אי אפשר לחלקם. כי הם [[טעמים וראיות רבות]] בדרך נפלא מאד. וכל אחד נעוץ וקשור בחברו (עיין בספר פרפראות לחכמה בתחלתו).
> **English:** And you, the serious student, should understand in the Rebbe’s words that there are times when, in an awesomely intricate and pleasing fashion, he brings two or three proofs for one point. However, due to the cursive style in which the material is presented, it may seem as if there is only one proof. Such is the manner of this book: often using “because” or “for” or some similar word more than once within a single statement, thus making it appear as if it is but a single reason and proof, when in truth there are a number of reasons. But, because each one is linked to the next, it is impossible to separate them. For numerous are the [[reasons and proofs]], set forth in an amazing way, each one fastened and bound to the next (see Parparaot LeChokhmah’s Introduction).

**Note:** Counterbalance: praises depth, reasoning, proofs, or careful study.

### ann_0007 — Introduction, segment 31
**Labels:** COUNTER_POSITIVE_INTELLECT, COUNTER_DEEP_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** והמעין באמת. מי שיש לו מח בקדקדו. יבין מאליו עמקות הדברים. שהם רחבים ועמקים מני ים. גבה משמים ועמק מתהום. ומי שרוצה לטעם צוף דבש אמרי נעם האלו צריך [[להעמיק בעין האמת בעיון גדול]] הדק היטב להבין הדבר על מתכנתו עד מקום שיד שכלו מגעת. [[אשרי אדם מצא חכמה]] ואדם יפיק תבונה להבין היטב פשטיות הדברים האלה הנאמרין בספר הקדוש הזה.
> **English:** Anyone who has a brain in his head and studies these teachings with an open mind will, on his own, appreciate their depth. They are ‘broader and deeper than the sea’ (cf. Job 11:9), ‘higher than the sky, deeper than the depths’ (cf. Proverbs 25:3). Anyone who wants to taste the sweet nectar of these words should [[analyze them honestly and in great depth]], understanding each matter in its context as best he possibly can. “[[Happy is the one who has found wisdom]] and who draws insight” (Proverbs 3:13), understanding well the simple meaning of the lessons which appear in this holy book (see Tzaddik #353,#361, #362, #365).

**Note:** Counterbalance: positively values holy intellect/wisdom/daat. Counterbalance: praises depth, reasoning, proofs, or careful study.

### ann_0009 — Introduction, segment 34
**Labels:** SIMPLICITY_PSHITUT, PRACTICE_OVER_STUDY
**Stance:** supports qualified anti-intellectual reading | **Score:** 4

> **Hebrew:** כי [[לא המדרש הוא העקר אלא המעשה]] כמבאר כבר כמה פעמים. שכל עקר כונתו הקדושה בכל תורה ותורה שגלה. ובכל דבור ודבור שיצא מפיו הקדוש הכל היה רק בשביל לזכות את ישראל להביאם לידי מעשה ישרה. לרמז להם מרחוק ומקרוב להורות להם עצות ותחבולות. עמקות ונפלאות. להתקרב להשם יתברך מכל מקום שהוא. כאשר יראה הרואה בעיניו אם ירצה להסתכל בעין האמת לאמתו. כי כל כונתו הקדושה היה רק שנשתדל להבין העבודה והעצות היוצאים מכל תורה ותורה. ושנבקש מהשם יתברך ונשתטח לפניו יתברך ונשתדל לקים ככל הכתוב בהם ב[[פשיטות]].
> **English:** This is because “[[study alone is not the main thing—doing is]]” (Avot 1:17), as has been explained in a number of places (see Rabbi Nachman’s Wisdom #19, #27, etc.). The essence of his holy intention in each teaching that he revealed and in every statement which issued from his holy lips was only in order to add merit to Israel and bring them to [[upright actions]], to hint to them from far and near, to teach them fantastic counsel and guidance in drawing closer to the Holy One from wherever one is. This the observer will surely notice provided he chooses to view it with an honest and open eye. For the Rebbe’s whole intention was only that we diligently work at understanding the service and advice which come out of each lesson, beseeching God, prostrating ourselves before Him and striving, with [[simplicity]], to fulfill all that appears in them.

**Note:** Elevates temimut/pshittut—simple, unsophisticated service of God. Subordinates study or discourse to concrete practice.

### ann_0012 — Likutei Moharan I, Lesson 1, segment 2.1
**Labels:** COUNTER_POSITIVE_INTELLECT
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** כִּי אִישׁ הַיִּשְׂרְאֵלִי צָרִיךְ תָּמִיד לְהִסְתַּכֵּל בְּהַשֵּׂכֶל שֶׁל כָּל דָּבָר, וּ[[לְקַשֵּׁר עַצְמוֹ אֶל הַחָכְמָה וְהַשֵּׂכֶל]] שֶׁיֵּשׁ בְּכָל דָּבָר, כְּדֵי שֶׁיָּאִיר לוֹ הַשֵּׂכֶל שֶׁיֵּשׁ בְּכָל דָּבָר לְהִתְקָרֵב לְהַשֵּׁם יִתְבָּרַךְ עַל־יְדֵי אוֹתוֹ הַדָּבָר, כִּי [[הַשֵּׂכֶל הוּא אוֹר גָּדוֹל, וּמֵאִיר]] לוֹ בְּכָל דְּרָכָיו, כְּמוֹ שֶׁכָּתוּב (קהלת ח׳:א׳): חָכְמַת אָדָם תָּאִיר פָּנָיו.
> **English:** 2. For the Jew must always focus on the inner intelligence of every matter, and bind himself to the wisdom and inner intelligence that is to be found in each thing. This, so that the intelligence which is in each thing may enlighten him, that he may draw closer to God through that thing. For the inner intelligence is a great light that shines for a person in all his ways. As it is written (Ecclesiastes 8:1), “A person’s wisdom causes his countenance to shine.”

**Note:** Counterbalance: positively values holy intellect/wisdom/daat.

### ann_0014 — Likutei Moharan I, Lesson 1, segment 2.4
**Labels:** COUNTER_POSITIVE_INTELLECT
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** וְזֶה בְּחִינַת חֵית, לְשׁוֹן חִיּוּת, כִּי הַחָכְמָה וְהַשֵּׂכֶל הוּא הַחִיּוּת שֶׁל כָּל דָּבָר, כְּמוֹ שֶׁכָּתוּב (קהלת ז׳:י״ב): הַ[[חָכְמָה תְּחַיֶּה]] וְכוּ'.
> **English:** And this is the concept of the CheT. It suggests ChiuT (life). For the wisdom and the inner intelligence are the vitality of all things, as in (Ecclesiastes 7:12), “[[Wisdom gives life]] to those who possess it.”

**Note:** Counterbalance: positively values holy intellect/wisdom/daat.

### ann_0015 — Likutei Moharan I, Lesson 1, segment 2.9
**Labels:** COUNTER_TORAH_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 1

> **Hebrew:** וְצָרִיךְ כָּל אֶחָד לִתֵּן כֹּחַ לִבְחִינַת מַלְכוּת דִּקְדֻשָּׁה לְהִתְגַּבֵּר עַל מַלְכוּת דְּסִטְרָא אָחֳרָא, וּכְמוֹ שֶׁאָמְרוּ רַבּוֹתֵינוּ זִכְרוֹנָם לִבְרָכָה (ברכות ה): לְעוֹלָם יַרְגִּיז אָדָם יֵצֶר טוֹב עַל יֵצֶר הָרָע. וְעַל־יְדֵי מַה נוֹתֵן כֹּחַ לְמַּלְכוּת דִּקְדֻשָּׁה, [[עַל־יְדֵי הַתּוֹרָה]] שֶׁהוּא עוֹסֵק בְּכֹחַ (כְּמוֹ שֶׁאָמְרוּ רַבּוֹתֵינוּ זִכְרוֹנָם לִבְרָכָה שָׁם: לְעוֹלָם יַרְגִּיז וְכוּ', אִי אָזִיל – מוּטָב, וְאִם לָאו – יַעֲסֹק בַּתּוֹרָה). וּכְמוֹ שֶׁאָמְרוּ רַבּוֹתֵינוּ זִכְרוֹנָם לִבְרָכָה (קדושין ל:): אִם פָּגַע בְּךָ מְנֻוָּל זֶה, מָשְׁכֵהוּ לְ[[בֵית־הַמִּדְרָש]]ׁ,
> **English:** Each person is required to give strength to the Kingdom of Holiness so that it may overpower the Kingdom of the Other Side. As our Sages taught: A person should always incite the good inclination against the evil inclination (Berakhot 5a). And how is strength given to the Kingdom of Holiness? [[By means of the Torah study]] that a person engages in with enthusiasm. {As our Sages taught: A person should always incite… If it leaves, good; if not, he should [[engage in Torah study]] (ibid.).} And, as our Sages taught: If this rogue accosts you, drag him to the house of study (Kiddushin 30b).

**Note:** Counterbalance: Torah learning itself is valued as a remedy.

### ann_0003 — Introduction, segment 26
**Labels:** COUNTER_DEEP_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** גם תבין ותראה. כי בכל דברי הספר הזה יש בהם [[עמקות גדול]] מאד בכל תורה ותורה. עמקות לפנים מעמקות בכלל ובפרט ובפרטי פרטיות. וכאשר שמעתי מפיו הקדוש ז”ל. שפעם אחת אמר בהתורה שלי יש [[עמקות גדול]]: כי הלא כה דברי הספר הקדוש הזה כאש וכפטיש יפוצץ סלע. כל תורה ותורה מתחלק לכמה וכמה הקדמות יקרות חדשות ונפלאות ולכמה טעמים וענינים היוצאים לרב מכל תורה ותורה.
> **English:** Understand and see as well that all the words of each and every lesson in this book contain [[great depth]]; there is great profundity in the totality, in the specific, and in the fine details [of the lesson]. As I myself heard from Rebbe Nachman’s holy lips, when he said, “There are [[great depth]]s to my teachings” (Tzaddik #347, #348). Why, “the words of this holy work are like a fire and like a hammer splitting rock” (Jeremiah 23:29; see Kiddushin 30b). Each lesson can be divided into numerous new and vital rudiments, and into the various topics and subjects which emerge from each teaching.

**Note:** Counterbalance: praises depth, reasoning, proofs, or careful study.

### ann_0004 — Introduction, segment 27
**Labels:** COUNTER_DEEP_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** כי כל תורה ותורה מדברי התורות הנאמרים בספר הקדוש הזה. הוא בנין גדול נפלא ונורא וחזק מאד. בנוי לתלפיות. תל שהכל פונים בו. כלול מכמה וכמה חדרים. חדר לפנים מחדר. וחדר לפנים מחדר. וחלונות ופתחים פתוחים מזה לזה ומזה לזה. וכל חדר וחדר וכל טעם וענין והקדמה הנמצאים בפרטות בכל תורה ותורה. יש בכל אחד ואחד [[עמקות גדול]] מאד מאד. וכל מה שהולכין ומתרבין הטעמים והענינים יש בהם עמקות (עמקות) יותר ויותר. כמים לים מכסים. וערום יבין לאשורו
> **English:** For each and every discourse that appears in this holy book is in itself an awesome and mighty structure—“built fortified” (Song of Songs 4:4), a fortress to which all turn (Berakhot 30a; Shir HaShirim Rabbah 4:11)—comprising many chambers, room within room within room, with windows and openings leading from one to another. And each and every chamber, each explanation, topic and rudiment which appears in a teaching has in it very [[great depth]]. The more these explanations and topics expand—as the “waters cover the sea” (Isaiah 11:9)—the deeper and deeper they get, so that “the clever man studies deeply his way” (Proverbs 14:15).

**Note:** Counterbalance: praises depth, reasoning, proofs, or careful study.

### ann_0006 — Introduction, segment 30
**Labels:** COUNTER_DEEP_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** והנה לפי גדל העמקות של כל דבור ודבור. היה מהראוי לכתב בכל פעם ודוק או והבן ועין היטב. וכיוצא באלו הלשונות המורים למעין שישים עין עיונו שם להבין היטב. אך ראה ראיתי. כי אם כן יהיה ההכרח לכתב כמעט אצל כל דבור ודבור לשונות כאלו. לפי עצם ערבת מתיקת השכל והעמקות שיש בכל ענין וכמעט בכל דבור. ועפ"י רב יש [[עמקות גדול]] מאד בדבריו אשר לא יספיק שום לשון מאלו הלשונות. על כן החדלתי את עטי. ומנעתי את עצמי מלכתב שום לשון מלשונות הנ"ל. רק לפעמים ולעתים רחוקות נשמט מתחת הקלמוס איזה לשון כזה.
> **English:** Indeed, because of the [[great depth]] of each and every statement, it would have been fitting to write each time” read carefully,” or “understand this,” or “study this well,” or some similar expression cautioning the reader to pay close attention to the point being made so as to understand it well. But I realized that if that were the case, it would be necessary to write some such comment following just about every point, considering the abundant sweetness of the intellect and depth contained in every topic and in almost every statement. In general, there is such [[great depth]] to the Rebbe’s words that none of these expressions could suffice. I have therefore withheld my pen and kept myself from employing any such language, although occasionally and upon rare instances some such expression did escape from the quill.

**Note:** Counterbalance: praises depth, reasoning, proofs, or careful study.

### ann_0008 — Introduction, segment 33
**Labels:** COUNTER_DEEP_STUDY
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** וכל כתבי האר"י ז"ל ומאמרי הזהר הקדוש ותקונים וכל דרכי הקבלה הקדושה. כלם כאחד כלולים בדברי הספר הקדוש הזה. וכל תורה ותורה מדברת מכונות מיחדות מאיזה מצוה ומשער היחוד מהעץ חיים. בדרך נפלא ונורא מאד כאשר עינינו ראו ולא זר אשר פתח עינינו והראה לנו לפעמים כטפה מן הים מעצם כונתו. וכאשר הובא בתוך הספר לפרקים איזה רמזים בעלמא. כי כל תורה ותורה כלול מפרד"ס ובכל אחד ואחד הן בדרך פשט הן בדרך רמז וכו'. בכלם יש בהם [[עמקות גדול]] נפלא ונורא מאד. אך עקר כונתו הקדושה הוא פרוש הפשוט שבכל תורה ותורה,
> **English:** All the writings of the holy Ari and the discourses of the holy Zohar and the Tikkuney Zohar, as well as all the ways of the Kabbalah, are all included in this holy book. Each and every lesson speaks about the deeper intentions of some mitzvah and of a particular portal in the Etz Chaim in some amazing and spectacular fashion. This we have seen with our own eyes and not through another’s, for the Rebbe opened our eyes and occasionally revealed a drop of his great intention, as is hinted at every so often in this work. For each lesson contains PaRDeS: Pshat—explanation of the simple meaning of the text; Remez—explanation of the allusions within the text; Drush— explanation of the text using the principles of hermeneutics; and Sod—explanation of the text according to its esoteric interpretation. In each approach, there is [[great depth]], though Rebbe Nachman’s primary intention is the sim…

**Note:** Counterbalance: praises depth, reasoning, proofs, or careful study.

### ann_0013 — Likutei Moharan I, Lesson 1, segment 2.3
**Labels:** COUNTER_POSITIVE_INTELLECT
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** וְזֶה בְּחִינַת שֶׁמֶשׁ, כִּי [[הַשֵּׂכֶל הוּא מֵאִיר]] לוֹ בְּכָל דְּרָכָיו כְּמוֹ הַשֶּׁמֶשׁ. וְזֶה בְּחִינַת (משלי ד׳:י״ח): וְאֹרַח צַדִּיקִים כְּאוֹר נֹגַהּ הוֹלֵךְ וָאוֹר עַד נְכוֹן הַיּוֹם.
> **English:** And this is the concept of sun. For the inner intelligence shines for him in all his ways, like the sun. This corresponds to (Proverbs 4:18), “The path of the righteous is like radiant sunlight, shining ever brighter as it approaches noon.”

**Note:** Counterbalance: positively values holy intellect/wisdom/daat.

### ann_0016 — Likutei Moharan I, Lesson 1, segment 4.3
**Labels:** COUNTER_POSITIVE_INTELLECT
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** וְעַל כֵּן נֶאֱמַר בְּיוֹסֵף (דברים ל״ג:י״ז): בְּכוֹר שׁוֹרוֹ הָדָר לוֹ. בְּכוֹר הוּא בְּחִינַת הַשֵּׂכֶל כַּנַּ"ל. וְזֶהוּ שׁוֹרוֹ – לְשׁוֹן הִסְתַּכְּלוּת, כִּי צְרִיכִין לְהִסְתַּכֵּל בְּהַשֵּׂכֶל שֶׁיֵּשׁ בְּכָל דָּבָר כַּנַּ"ל. וְזֶהוּ הָדָר לוֹ, תִּרְגֵּם אוּנְקֶלוּס: זִיו לֵיהּ, לְשׁוֹן אוֹר, כִּי [[הַשֵּׂכֶל מֵאִיר לוֹ בְּכָל דָּבָר; אֲפִלּוּ בְּמָקוֹם שֶׁהָיָה אֹפֶל וָחֹשֶׁךְ, מֵאִיר]] לוֹ הַשֵּׂכֶל, כְּשֶׁזּוֹכֶה לְהִסְתַּכֵּל עַל הַשֵּׂכֶל שֶׁיֵּשׁ שָׁם בְּכָל דָּבָר, וּמְקָרֵב אוֹתוֹ לְהַשֵּׁם יִתְבָּרַךְ:
> **English:** It is therefore said of Yosef: “The firstborn of his shor (oxen), grandeur is his” (Deuteronomy 33:17). “Firstborn” corresponds to the inner intelligence, as above. And this is “his shor,” it suggests gazing. For it is necessary to focus on the inner intelligence of every matter. Onkelos renders “grandeur is his” as “radiance is his,” an expression of luminance. For the inner intelligence shines for him in each thing. Even in a place that had been dark and obscure, the inner intelligence shines for him—when he merits focusing on the inner intelligence that is found in each thing—and brings him closer to God.

**Note:** Counterbalance: positively values holy intellect/wisdom/daat.

### ann_0040 — Likutei Moharan I, Lesson 10, segment 9.8
**Labels:** COUNTER_POSITIVE_INTELLECT
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** וְאַפְקִינְהוּ, וְאִחְרַךְ אִחְרוּכֵי – אִחְרַךְ, לְשׁוֹן חַיִּים וַאֲרִיכוּת יָמִים, כְּמַאֲמַר חֲכָמֵינוּ זִכְרוֹנָם לִבְרָכָה (עירובין נד:): לֹא יַחֲרֹךְ רְמִיָּה צֵידוֹ – לֹא יִחְיֶה וְלֹא יַאֲרִיךְ, וְהַיְנוּ: וְאִיחְרַךְ אִיחְרוּכֵי – לְשׁוֹן חַיִּים וַאֲרִיכַת יָמִים, כִּי עַל־יְדֵי בִּטּוּל הַגַּאֲוָה, הַיְנוּ הָעֲבוֹדָה זָרָה, עַל־יְדֵי־זֶה הַחָכְמָה עַל תִּקּוּנָהּ כַּנַּ"ל, וְעַל־יְדֵי חָכְמָה יִחְיֶה וְיַאֲרִיךְ יָמִים, כְּמוֹ שֶׁכָּתוּב (קהלת ז׳:י״ב): הַ[[חָכְמָה תְּחַיֶּה]] וְכוּ'.
> **English:** When he removed it, it was ichrakh (scorched) entirely — The word iChRaKh has the connotation of life and length of days. As our Sages taught: “The slothful man will not YaChaRoKh (roast) his catch” (Proverbs 12:27) —he will neither YiChyeh (live) nor YaaRiKh (have length of days) (Eruvin 54b). This is the meaning of scorched entirely: it alludes to life and length of days. By eliminating haughtiness—i.e., idolatry—[one’s] wisdom is as it should be. And with wisdom, a person lives long, as is written (Ecclesiastes 7:12), “[[Wisdom gives life]] to those who possess it.”

**Note:** Counterbalance: positively values holy intellect/wisdom/daat.

### ann_0045 — Likutei Moharan I, Lesson 17, segment 6.10
**Labels:** COUNTER_POSITIVE_INTELLECT
**Stance:** counterevidence to broad anti-intellectual reading | **Score:** 3

> **Hebrew:** לְהַפְנוֹת אֵלֶיךָ כָּל רִשְׁעֵי אָרֶץ – זֶה בְּחִינַת הַגֵּרִים. יַכִּירוּ וְיֵדְעוּ כָּל יוֹשְׁבֵי תֵבֵל – זֶה בְּחִינַת [[שְׁלֵמוּת הַדַּעַת]] שֶׁנַּעֲשֶׂה עַל־יְדֵי זֶה כַּנַּ"ל:
> **English:** “To turn all the wicked of the earth towards You”—this is the concept of converts. “All the inhabitants of the world will recognize and know”—this is the concept of perfected knowledge which is achieved through this, as mentioned above.

**Note:** Counterbalance: positively values holy intellect/wisdom/daat.

## How to use the JSON

- `annotations[]` contains every selected passage with `he_text`, `en_text`, `he_highlighted`, `en_highlighted`, `labels`, `stance`, and `annotation_note`.
- Highlights are marked with `[[double brackets]]`.
- `source_path_zero_based` preserves exact JSON locations; `source_path_one_based` gives human-readable one-based locations.
- The safest thesis is not that Rebbe Nachman rejects intellect, but that he rejects external/speculative/philosophical wisdom when detached from faith, mitzvot, temimut, and practice.